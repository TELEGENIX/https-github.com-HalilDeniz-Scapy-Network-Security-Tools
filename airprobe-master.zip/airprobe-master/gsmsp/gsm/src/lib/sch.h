// $Id: sch.h,v 1.3 2007/03/14 05:44:53 jl Exp $

int decode_sch(const unsigned char *, int *, int *);
