
#ifdef __cplusplus
extern "C" {
#endif

void l2_data_out_Bbis(int fn, const unsigned char *data, int len);
void l2_data_out_B(int fn, const unsigned char *data, int len);

#ifdef __cplusplus
}
#endif
