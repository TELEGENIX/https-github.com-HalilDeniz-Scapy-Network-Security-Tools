// $Id: sch.h,v 1.1.1.1 2007-06-01 04:26:57 jl Exp $

int decode_sch(const unsigned char *, int *, int *);
