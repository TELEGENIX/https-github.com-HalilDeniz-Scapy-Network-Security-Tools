// $Id: display.h,v 1.1.1.1 2007-06-01 04:26:57 jl Exp $

void dump_raw(unsigned char *, unsigned int);
void display_raw(unsigned char *, unsigned int);
