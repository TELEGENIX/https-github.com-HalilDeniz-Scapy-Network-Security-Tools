// $Id: tun.h,v 1.1.1.1 2007-06-01 04:26:57 jl Exp $

int mktun(const char *, unsigned char *);
int write_interface(int, unsigned char *, unsigned int, unsigned char *);
