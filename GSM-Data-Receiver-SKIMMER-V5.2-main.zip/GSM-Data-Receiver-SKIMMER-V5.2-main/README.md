<h1> GSM Data Receiver Skimmer V5.2 (EDUCATIONAL PURPOSES ONLY)</h1>
<h3>GSM Data Receiver Skimmer V5.2 Is a software that collects Credit Card Dumps from POS and ATMs in a specific frequency</h3>

![image](https://github.com/user-attachments/assets/bb636261-5acf-4098-8cce-b22a710f4923)

For more information please contact <a href="https://t.me/gsmcloner"> @gsmcloner on Telegram</a> <a>Used to be @pandaskimmer</a>
